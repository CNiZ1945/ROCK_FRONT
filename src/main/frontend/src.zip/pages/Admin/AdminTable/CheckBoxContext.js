import { createContext } from 'react';

//CheckBoxContext
const CheckBoxContext = createContext();

export default CheckBoxContext;
