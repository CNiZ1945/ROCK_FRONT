import React from "react";
import styled from "styled-components";

//있으면 작성함- 기존 회원가입 이력이 존재할 시
function Leave() {
    return (
        <>

        </>
            );
}
export default Leave;