import profile1 from "./profile_img/Profile_1.svg"
import profile2 from "./profile_img/Profile_2.svg"
import profile3 from "./profile_img/Profile_3.svg"
import profile4 from "./profile_img/Profile_4.svg"
import profile5 from "./profile_img/Profile_5.svg"

const DogImg = "https://cdn-icons-png.flaticon.com/512/4359/4359634.png";
const BirdImg = "https://cdn-icons-png.flaticon.com/512/4359/4359669.png";
const FishImg = "https://cdn-icons-png.flaticon.com/512/4359/4359874.png";
const CatImg = "https://cdn-icons-png.flaticon.com/512/4359/4359704.png";
const TurtleImg = "https://cdn-icons-png.flaticon.com/512/4359/4359624.png";



export {DogImg, BirdImg, FishImg, CatImg, TurtleImg,  profile1, profile2, profile3, profile4, profile5}

