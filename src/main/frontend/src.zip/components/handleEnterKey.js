
// 엔터키 기능
const handleEnterKey = (e) => {

    
    if(e.key === 'Enter'){
        console.log('input Enter key');
        
    }
}
export default handleEnterKey;